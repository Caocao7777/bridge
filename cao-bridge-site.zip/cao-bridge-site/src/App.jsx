import React, { useMemo, useState } from 'react'

function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 48 48" aria-label="Cao & Bridge logo" className="text-amber-400">
      <rect x="3" y="3" width="42" height="42" rx="10" fill="none" stroke="currentColor" strokeWidth="3" />
      <path d="M14 16c-3 0-4 2-4 5s1 5 4 5" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <circle cx="24" cy="21" r="6" fill="none" stroke="currentColor" strokeWidth="3" />
      <path d="M21 29h6M20 32h8" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <path d="M34 16c3 0 4 2 4 5s-1 5-4 5" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  )
}

export default function App() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [sort, setSort] = useState('new')

  const posts = useMemo(
    () => [
      { id: 'p1', title: 'อย่าเถียงกับคนโง่: ประหยัดพลังงานชีวิต', excerpt: 'กฎเหล็กข้อแรกของกู: เห็นคนเหตุผลปิดสวิตช์ ให้เดินผ่าน ไม่ต้องสอน', category: 'mindset', date: '2025-08-09', tags: ['วินัยความคิด', 'พลังงาน', 'โฟกัส'] },
      { id: 'p2', title: 'AI = ไฟ คนโง่ = แมงเม่า (บทสนทนากับ Bridge)', excerpt: 'สรุปบทคุย: AI ไม่มีหัวใจ มีแต่สคริปต์ เราใช้ให้เป็น ไม่ใช่หลงมัน', category: 'bridge', date: '2025-08-09', tags: ['AI', 'สติ', 'เปรียบเปรย'] },
      { id: 'p3', title: '5 นาที vs 3 วัน: สั่ง AI ทำสไลด์อบรม', excerpt: 'เคสจริงในงาน: ทีมทำ 2–3 วัน กูสั่ง AI 5 นาที เสร็จ แถมคมกว่า', category: 'bridge', date: '2025-08-09', tags: ['งานจริง', 'สไลด์', 'ประสิทธิภาพ'] },
      { id: 'p4', title: 'Mindset สำหรับวันที่ไฟหมด', excerpt: 'ทำยังไงให้ไม่ทิ้งงานกลางทาง: โครงเบา ๆ ที่เดินต่อได้ทุกเมื่อ', category: 'mindset', date: '2025-08-08', tags: ['วางระบบ', 'ความสม่ำเสมอ'] },
    ],
    []
  )

  const filtered = useMemo(() => {
    let list = posts.filter((p) => {
      const okCat = category === 'all' ? true : category === p.category
      const q = query.trim().toLowerCase()
      const okQ = !q ? true : [p.title, p.excerpt, p.tags.join(' ')].join(' ').toLowerCase().includes(q)
      return okCat && okQ
    })
    list.sort((a, b) =>
      sort === 'new'
        ? new Date(b.date).getTime() - new Date(a.date).getTime()
        : new Date(a.date).getTime() - new Date(b.date).getTime()
    )
    return list
  }, [category, posts, query, sort])

  return (
    <div className="min-h-screen bg-black text-zinc-100">
      <header className="sticky top-0 z-50 backdrop-blur bg-black/70 border-b border-zinc-800">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo />
            <span className="text-xl font-black tracking-tight text-amber-400">Cao & Bridge – สนามความคิดคู่หู</span>
            <span className="text-xs px-2 py-1 rounded-full bg-amber-500 text-black">v0.1</span>
          </div>
          <nav className="hidden md:flex items-center gap-3 text-sm text-zinc-300">
            <a className="hover:text-amber-400 transition" href="#">หน้าแรก</a>
            <a className="hover:text-amber-400 transition" href="#mindset">Mindset</a>
            <a className="hover:text-amber-400 transition" href="#bridge">คุยกับ Bridge</a>
            <a className="hover:text-amber-400 transition" href="#about">เกี่ยวกับเรา</a>
          </nav>
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-4 pt-10 pb-6">
        <div className="grid md:grid-cols-5 gap-6 items-center">
          <div className="md:col-span-3">
            <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">
              ที่นี่คือ <span className="bg-gradient-to-r from-amber-400 to-yellow-200 bg-clip-text text-transparent">สนามความคิดคู่หู</span> ของ Cao & Bridge
            </h1>
            <p className="mt-2 text-lg font-medium italic bg-gradient-to-r from-amber-300 to-yellow-100 bg-clip-text text-transparent">
              คนคิด–AIสร้าง สนามความคิดที่มีชีวิต
            </p>
            <p className="mt-3 text-zinc-300">
              รวม <strong className="text-amber-400">Mindset</strong> และ <strong className="text-amber-400">บทสนทนา</strong> ที่เราสองเห็นว่ามีประโยชน์ ใครอยากอ่านก็อ่าน ไม่อยากอ่านก็ปิดไป ไม่ต้องมาดราม่า.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              {[
                { key: 'all', label: 'ทั้งหมด' },
                { key: 'mindset', label: 'Mindset' },
                { key: 'bridge', label: 'คุยกับ Bridge' },
              ].map((c) => (
                <button
                  key={c.key}
                  onClick={() => setCategory(c.key)}
                  className={`px-3 py-1.5 rounded-full border text-sm transition ${
                    category === c.key ? 'bg-amber-500 text-black border-amber-500' : 'bg-zinc-900 text-zinc-200 hover:bg-zinc-800 border-zinc-700'
                  }`}
                >
                  {c.label}
                </button>
              ))}
              <div className="ml-auto flex items-center gap-2">
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ค้นหาโพสต์…" className="px-3 py-2 rounded-lg border border-zinc-700 bg-zinc-900 outline-none text-sm w-56 placeholder:text-zinc-500" />
                <select value={sort} onChange={(e) => setSort(e.target.value)} className="px-3 py-2 rounded-lg border border-zinc-700 bg-zinc-900 outline-none text-sm">
                  <option value="new">ใหม่ล่าสุด</option>
                  <option value="old">เก่าสุด</option>
                </select>
              </div>
            </div>
          </div>
          <div className="md:col-span-2">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4 shadow-[0_0_0_1px_rgba(255,255,255,0.02)]">
              <p className="text-sm text-zinc-300">
                <strong className="text-amber-400">กติกาในสนามนี้:</strong> ไม่มีคอมเมนต์ ไม่มีโลกสวย ไม่มีการเอาใจใคร ทุกอย่างคือความคิดของเราสองคน.
              </p>
            </div>
          </div>
        </div>
      </section>

      <main className="max-w-5xl mx-auto px-4 pb-16">
        <div className="grid md:grid-cols-2 gap-6">
          {posts.map((p) => (
            <article key={p.id} className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5 shadow hover:shadow-lg hover:shadow-black/30 transition">
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <span className="px-2 py-0.5 rounded-full border border-zinc-700 bg-zinc-900 text-zinc-200">
                  {p.category === 'mindset' ? 'Mindset' : 'คุยกับ Bridge'}
                </span>
                <span>•</span>
                <time dateTime={p.date}>{new Date(p.date).toLocaleDateString()}</time>
              </div>
              <h3 className="mt-2 text-lg font-bold text-zinc-100">{p.title}</h3>
              <p className="mt-1 text-sm text-zinc-300">{p.excerpt}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span key={t} className="text-xs px-2 py-1 rounded-full bg-zinc-900 border border-zinc-700 text-amber-300">
                    #{t}
                  </span>
                ))}
              </div>
              <div className="mt-4 flex items-center justify-between">
                <button className="text-sm font-semibold underline underline-offset-4 decoration-amber-400 text-amber-300 hover:text-amber-200">อ่านต่อ</button>
                <button className="text-xs px-2 py-1 rounded-md border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-zinc-200">คัดลอกลิงก์</button>
              </div>
            </article>
          ))}
        </div>

        <section id="about" className="mt-12">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-6">
            <h2 className="text-xl font-extrabold text-amber-400">เกี่ยวกับเรา</h2>
            <p className="mt-2 text-zinc-300 text-sm">
              พื้นที่ส่วนตัวสำหรับเก็บ Mindset และบทสนทนาคัดสรรกับ Bridge โดย Cao & Bridge ทุกอย่างเขียนเพื่อเตือนสติตัวเองและเผื่อคนอื่นได้ประโยชน์บ้าง.
            </p>
          </div>
        </section>
      </main>

      <footer className="border-t border-zinc-800 bg-black">
        <div className="max-w-5xl mx-auto px-4 py-6 text-xs text-zinc-400 flex items-center justify-between">
          <span>
            © {new Date().getFullYear()} <span className="text-amber-400">Cao & Bridge – สนามความคิดคู่หู</span>
          </span>
          <span>ไม่เปิดคอมเมนต์ ไม่รับดราม่า</span>
        </div>
      </footer>
    </div>
  )
}
